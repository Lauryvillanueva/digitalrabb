<?php

// Check for empty fields
if(empty($_POST['nombre'])      ||
   empty($_POST['email'])     ||
   empty($_POST['telefono'])     ||
   empty($_POST['mensaje'])     ||
   empty($_POST['optradio'])
   )
   {
   echo "No arguments Provided!";
   return false;
   }
   
$name = strip_tags(htmlspecialchars($_POST['nombre']));
$email_address = strip_tags(htmlspecialchars($_POST['email']));
$phone = strip_tags(htmlspecialchars($_POST['telefono']));
$message = strip_tags(htmlspecialchars($_POST['mensaje']));
$optradio = strip_tags(htmlspecialchars($_POST['optradio']));

/* CONECTAR CON BASE DE DATOS **************** */
    $usuario = "digitalrabb_admin";
    $password = "lalivior199507";
    $servidor = "localhost";
    $basededatos ="digitalrabb_contacto";
	
	$conexion = mysqli_connect  ($servidor,$usuario,$password)  or die ("No se ha podido conectar con el servidor de Base de datos");
	$db = mysqli_select_db($conexion, $basededatos) or die ("Upps! Pues va a ser que no se ha podido conectar a la Base de datos");
	
	
            //REALIZAR CONSULTA
			$sql = "INSERT INTO datos (nombre, email, telefono,mensaje,optradio) VALUES ('$name','$email_address','$phone','$message','$optradio')";
			if (mysqli_query($conexion, $sql)) {
				  echo "Enviado";
				  return true;
			} 
			else
			{		
				  echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
				  return false;
			}
			mysqli_close($conexion);
			
           

?>

