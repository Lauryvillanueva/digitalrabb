function main() {

(function () {
   'use strict';

  	$('a.page-scroll').click(function() {
        if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
          var target = $(this.hash);
          target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
          if (target.length) {
            $('html,body').animate({
              scrollTop: target.offset().top - 40
            }, 900);
            return false;
          }
        }
      });

    /*====================================
    Show Menu on Book
    ======================================*/
    $(window).bind('scroll', function() {
        var navHeight = $(window).height() - 100;
        if ($(window).scrollTop() > navHeight) {
            $('.navbar-default').addClass('on');
        } else {
            $('.navbar-default').removeClass('on');
        }
    });

    $('body').scrollspy({ 
        target: '.navbar-default',
        offset: 80
    })

  	$(document).ready(function() {
  	  $("#clients").owlCarousel({
  	      navigation : false, // Show next and prev buttons
  	      slideSpeed : 300,
  	      autoPlay:true,
  	      paginationSpeed : 400,
  	      autoHeight : true,
  	      items : 3,
  	      itemsDesktop : [1199, 3],
          itemsDesktopSmall : [979, 3],
          itemsTablet : [768, 3],
  	      itemsCustom : [
				        [0, 1],
				        [450, 2],
				        [600, 2],
				        [700, 2],
				        [1000, 3],
				        [1200, 3],
				        [1400, 3],
				        [1600, 3]
				      ],
  	  });
  	  
  	    $("#home").owlCarousel({
            singleItem:true,
            loop:false,
            autoPlay:true,
            autoplayTimeout:1000,
            autoplayHoverPause:false,
            slideSpeed : 200,
            paginationSpeed : 800,
            rewindSpeed : 1000,
            stopOnHover : false,
        });
		
	
  	});
	
	

  	

}());


}
main();